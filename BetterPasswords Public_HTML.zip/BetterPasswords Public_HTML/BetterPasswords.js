function generate() {
	var source = document.getElementById("source").value;
	var numbers = (Math.floor(1000 + Math.random() * 9000)).toString();
	numbers = numbers.substring(-2);
	if (source.length < 6){
		alert("Your original password must be more than 5 characters long! The password you entered was " + source.length + " characters long.");
		}
		
	else if(source.search(/[^A-Za-z\s]/) != -1){
		alert("Your original password must contain letters only. You entered '" + source + "'.");
	}
	else{
		document.getElementById("result").innerHTML = "<h2>Your new password:</h2> #" + source + numbers;
	}
}